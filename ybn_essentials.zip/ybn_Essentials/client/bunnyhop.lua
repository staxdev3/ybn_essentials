local NumberJump = 3
local JumpCount = 0

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)

        local ped = PlayerPedId()
        local chance = math.random(0, 100)

        if IsPedVaulting(ped) then
            if chance > 85 then
                SetPedToRagdoll(ped, 1000, 1000, 0, 0, 0, 0)
            end
        end

        if IsPedOnFoot(ped)
            and not IsPedSwimming(ped)
            and (IsPedRunning(ped) or IsPedSprinting(ped))
            and not IsPedClimbing(ped)
            and IsPedJumping(ped)
            and not IsPedRagdoll(ped)
        then
            JumpCount += 1

            if JumpCount >= NumberJump then
                ShakeGameplayCam("SMALL_EXPLOSION_SHAKE", 0.30)

                lib.notify({
                    id = 'anti_bunny_hop',
                    title = 'Stop jumping ',
                    description = "Take a Break and relax your legs.",
                    showDuration = false,
                    position = 'center-right',
                    style = {
                        backgroundColor = '#141517',
                        color = '#C1C2C5',
                        ['.description'] = {
                            color = '#909296'
                        }
                    },
                    icon ='person-running',
                    iconColor = '#686565ff'
                })

                SetPedToRagdoll(ped, 6000, 2400, 3)
                JumpCount = 0
            end
        else
            Citizen.Wait(500)
        end
    end
end)


AddEventHandler('esx:onPlayerSpawn', function()

    -- Set default relationships with the non-player characters.
    SetRelationshipBetweenGrou  (1, `AMBIENT_GANG_HILLBILLY`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `AMBIENT_GANG_BALLAS`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `AMBIENT_GANG_MEXICAN`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `AMBIENT_GANG_FAMILY`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `AMBIENT_GANG_MARABUNTE`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `AMBIENT_GANG_SALVA`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `AMBIENT_GANG_LOST`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `GANG_1`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `GANG_2`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `GANG_9`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `GANG_10`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `FIREMAN`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `MEDIC`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `COP`, `PLAYER`)
    SetRelationshipBetweenGroups(1, `PRISONER`, `PLAYER`)
end)

CreateThread(function()
    local sleep = true
    local IsPedArmed = IsPedArmed
    local IsPlayerFreeAiming = IsPlayerFreeAiming
    local DisableControlAction = DisableControlAction

    while true do
        if IsPedArmed(cache.ped, 6) or IsPlayerFreeAiming(cache.playerId) then
            sleep = false
            DisableControlAction(0, 22, true)
        end

        Wait(sleep and 1000 or 0)
    end
end)

