local headshotHits = {}

CreateThread(function()
    while true do
        Wait(0)

        if not config.headshots.enabled then
            Wait(1000)
            goto continue
        end

        local playerPed = PlayerPedId()

        if IsPedShooting(playerPed) then
            local _, entityHit = GetEntityPlayerIsFreeAimingAt(PlayerId())

            if entityHit and DoesEntityExist(entityHit) and IsEntityAPed(entityHit) then
                local bone = GetPedLastDamageBone(entityHit)

                
                if bone == 31086 then
                    local netId = NetworkGetNetworkIdFromEntity(entityHit)

                    if not headshotHits[netId] then
                        headshotHits[netId] = 0
                    end

                    headshotHits[netId] = headshotHits[netId] + 1


                    local currentHealth = GetEntityHealth(entityHit)
                    local bonusDamage = 25 * config.headshots.multiplier
                    SetEntityHealth(entityHit, currentHealth - bonusDamage)

               

                  
                    if headshotHits[netId] >= config.headshots.requiredHits then
                        SetEntityHealth(entityHit, 0)
                        headshotHits[netId] = 0
                    end
                end
            end
        end

        ::continue::
    end
end)