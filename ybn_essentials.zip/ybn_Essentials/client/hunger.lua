local config = require('config.config-hunger')

if not config.enable then return end

local lastHungerNotification = 0
local lastThirstNotification = 0

AddEventHandler(
    "esx_status:onTick",
    function(status)
        TriggerEvent(
            "esx_status:getStatus",
            "hunger",
            function(hunger)
                TriggerEvent(
                    "esx_status:getStatus",
                    "thirst",
                    function(thirst)
                        local hungerPercent = math.floor(hunger.getPercent())
                        local thirstPercent = math.floor(thirst.getPercent())

                        if hungerPercent <= 20 then
                            local currentTime = GetGameTimer()
                            if currentTime - lastHungerNotification >= 20000 then
                                lib.notify(
                                    {
                                        title = "You are really hungry go eat something in 10 minutes",
                                        description = "You are feeling hungry! You should eat something soon.",
                                        type = "error",
                                        duration = 5000,
                                        icon = "burger",
                                        iconColor = "#e09a43",
                                        position = "center-right"
                                    }
                                )
                                ShakeGameplayCam("SMALL_EXPLOSION_SHAKE", 0.3)
                                lastHungerNotification = currentTime
                            end
                        end

                        if thirstPercent <= 20 then
                            local currentTime = GetGameTimer()
                            if currentTime - lastThirstNotification >= 20000 then
                                lib.notify(
                                    {
                                        title = "you are really Thirst get some water",
                                        description = "You are feeling thirsty! You should drink something soon.",
                                        type = "error",
                                        duration = 5000,
                                        icon = "droplet",
                                        iconColor = "#437ee0",
                                        position = "center-right"
                                    }
                                )
                                ShakeGameplayCam("SMALL_EXPLOSION_SHAKE", 0.3)
                                lastThirstNotification = currentTime
                            end
                        end
                    end
                )
            end
        )
    end
)


