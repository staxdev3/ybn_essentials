fx_version 'cerulean'
game 'gta5'

author 'stax.dev3'
description 'ls_essentials for Fivem servers easy setup just drag and drop'
version '1.0.0'


shared_script '@ox_lib/init.lua'


client_scripts {
    'client/*.lua'
}


ui_page 'index.html'

files {
    'index.html'
}